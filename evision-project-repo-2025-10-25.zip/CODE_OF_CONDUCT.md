# Code of Conduct

We adhere to a simple standard: be respectful, assume good intent, and collaborate constructively.
Harassment, discrimination, and disrespectful behavior are not tolerated.
