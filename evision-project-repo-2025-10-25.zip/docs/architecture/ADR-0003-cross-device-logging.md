# ADR 0003 — Cross-Device Session Logging

## Decision
Log device-specific sessions (Windows, iOS) under `logs/` with message digests and metadata in `meta/`.

## Status
Accepted

## Consequences
- Device context preserved
- Tamper‑evident checksums for each message
