# ADR 0002 — Daily Update Pipeline

## Decision
Store daily updates under `daily_updates/` using YAML front‑matter and append a consolidated Change Log.

## Status
Accepted

## Consequences
- Simple Git-based history
- Easy rendering on GitHub Pages or docs sites
