# ADR 0004 — Change Log Aggregation

## Decision
Aggregate commits and research-session notes into each daily update’s Change Log. Provide a repo-level `CHANGELOG.md` extracted from the latest daily update(s).

## Status
Accepted

## Consequences
- Unified change visibility
- Simplifies stakeholder reviews
