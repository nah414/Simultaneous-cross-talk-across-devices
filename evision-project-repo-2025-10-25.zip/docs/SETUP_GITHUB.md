# GitHub Setup

1. Create a new empty repository on GitHub.
2. Add the remote and push the local repo.
3. Protect `main` branch and enable required status checks (optional).
