# Windows Setup

1. Install Git for Windows.
2. (Optional) Install Python 3.11+ and pipx.
3. Clone or initialize the repo and push to GitHub.
