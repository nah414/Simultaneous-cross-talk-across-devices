---
name: Feature request
about: Suggest an idea for this project
title: "[Feature] "
labels: ["enhancement"]
assignees: []
---

**Problem**
What problem are you trying to solve?

**Proposed solution**

**Alternatives considered**

**Additional context**
