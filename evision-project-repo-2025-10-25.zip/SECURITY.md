# Security Policy

- Report vulnerabilities privately to the maintainers.
- Do not include secrets in any commits or logs.
- Use environment variables for tokens (e.g., `GITHUB_TOKEN`) when running scripts.
