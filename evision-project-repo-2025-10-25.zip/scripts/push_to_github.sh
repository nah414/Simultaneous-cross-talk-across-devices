#!/usr/bin/env bash
set -euo pipefail
REMOTE_URL="${1:-}"
MAIN_BRANCH="${2:-main}"
if [[ -z "$REMOTE_URL" ]]; then
  echo "Usage: push_to_github.sh <REMOTE_URL> [main|default_branch]"
  exit 1
fi
git init
git add .
git commit -m "Bootstrap eVision repository with metadata and session logs"
git branch -M "$MAIN_BRANCH"
git remote add origin "$REMOTE_URL"
git push -u origin "$MAIN_BRANCH"
