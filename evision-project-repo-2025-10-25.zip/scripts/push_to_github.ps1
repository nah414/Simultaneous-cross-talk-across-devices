Param(
  [Parameter(Mandatory=$true)][string]$RemoteUrl,
  [string]$MainBranch = "main"
)
git init
git add .
git commit -m "Bootstrap eVision repository with metadata and session logs"
git branch -M $MainBranch
git remote add origin $RemoteUrl
git push -u origin $MainBranch
