# Contributing to eVision

Thanks for your interest in contributing! For this early phase, contributions focus on:
- Documentation improvements
- Architecture Decision Records (ADRs)
- Data ingestion & validation scripts for daily updates

## Workflow
1. Fork and create a feature branch.
2. Write clear docs and include tests where applicable.
3. Open a PR; ensure CI checks pass.

## Style
- Markdown for docs
- Keep ADRs short and decision‑oriented
- Use American English for consistency
