# eVision — Architecture & Session Logs

This repository captures the **foundation**, **metadata**, and **full session logs** for eVision as of **2025-10-25 (America/Chicago)**.
It is designed to be pushed to GitHub as the canonical starting point for the project’s documentation and architecture.
All content here is derived from our conversations and daily reports compiled on 2025-10-25.

## What’s inside

- `daily_updates/` — GitHub-ready daily update with YAML front‑matter and a consolidated Change Log.
- `logs/` — Full transcripts from **Windows** and **iOS** sessions **today**, with message digests for traceability.
- `meta/` — High‑level metadata (timezone, devices, authors), plus a machine‑readable message index with SHA‑256 hashes.
- `docs/` — Overview, Windows setup, GitHub setup, and initial ADRs (Architecture Decision Records).
- `.github/` — Issue/PR templates and a lightweight CI workflow for Markdown checks.
- `scripts/` — Cross‑platform helpers to initialize a Git repo and push it to GitHub.
- `CHANGELOG.md` — Extract of today’s Change Log for quick reference.

## Quick start (Windows PowerShell)

```powershell
# 1) Initialize git and create the repo locally
git init
git add .
git commit -m "Bootstrap eVision repository with metadata and session logs (2025-10-25)"

# 2) Create a new empty repository on GitHub (via UI), then set the remote and push
git remote add origin https://github.com/<YOUR_ORG_OR_USER>/evision.git
git branch -M main
git push -u origin main
```

> **Authors:** Adam Lisowski & Nova  
> **Timezone for automation and dates:** America/Chicago

---

## Notes on data provenance & privacy
- All logs included are from today’s sessions and the generated daily update(s).  
- No machine secrets, tokens, or credentials are included.  
- Hashes are provided for tamper‑evident provenance.
