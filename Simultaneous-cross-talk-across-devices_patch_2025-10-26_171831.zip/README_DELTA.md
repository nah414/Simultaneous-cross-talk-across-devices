
## New: Baseline Chart
Run after `scripts/normalize_sessions.py`:
```powershell
python scripts/plot_baseline.py
```
Outputs: `charts/latency_by_device.png`.
