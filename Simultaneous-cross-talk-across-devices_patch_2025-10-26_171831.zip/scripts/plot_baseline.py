
# scripts/plot_baseline.py
# Reads data/sessions_normalized.csv and plots latency by device.
import csv, pathlib
import matplotlib.pyplot as plt

ROOT = pathlib.Path(__file__).resolve().parents[1]
infile = ROOT / "data" / "sessions_normalized.csv"
charts_dir = ROOT / "charts"; charts_dir.mkdir(parents=True, exist_ok=True)

def load_rows():
    rows = []
    with open(infile, newline="", encoding="utf-8") as f:
        reader = csv.DictReader(f)
        for r in reader:
            rows.append(r)
    return rows

if __name__ == "__main__":
    rows = load_rows()
    by_dev = {}
    for r in rows:
        dev = r["device_type"]
        by_dev.setdefault(dev, []).append(float(r["latency_ms"]))
    # single-figure chart
    plt.figure()
    labels = list(by_dev.keys())
    values = [sum(v)/len(v) if v else 0 for v in by_dev.values()]
    plt.bar(labels, values)
    plt.ylabel("Average Latency (ms)")
    plt.title("Latency by Device")
    out = charts_dir / "latency_by_device.png"
    plt.savefig(out)
    print(f"Wrote chart: {out}")
