
# tools/collector_ios_notes.md
Until automation is in place, export basic session rows (timestamp, device, latency, task, outcome)
from your notes and append to `data/sessions.csv` in the same comma-separated format.
