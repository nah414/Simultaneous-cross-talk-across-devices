
# tools/collector_windows.ps1
# Minimal example: write a CSV row with timestamp and dummy metrics.
param(
  [string]$DeviceId = "WIN-LAPTOP"
)
$ts = (Get-Date).ToString("s")
$line = "$ts,$DeviceId,Windows,10.0,Edge141,25,7.8,,false,analysis,success"
New-Item -ItemType Directory -Force -Path "data" | Out-Null
Add-Content -Path "data/sessions.csv" -Value $line
Write-Output "Logged: $line"
