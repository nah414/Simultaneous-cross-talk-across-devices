
# Simultaneous Cross-Talk Across Devices (payload)
Schema + collectors + normalizer to analyze iOS vs Windows session performance.

## Quickstart (Windows)
```powershell
python -m venv .venv
. .venv/Scripts/Activate.ps1
python scripts/normalize_sessions.py
```
Then open the resulting CSV at `data/sessions_normalized.csv`.
```powershell
# Example: log a Windows session row
./tools/collector_windows.ps1 -DeviceId "WIN-ADAM"
python scripts/normalize_sessions.py
```
