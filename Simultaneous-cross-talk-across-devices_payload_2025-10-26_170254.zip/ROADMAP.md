
# ROADMAP
- Phase A: Logging (this commit)
- Phase B: Baseline EDA (latency by device, session length, error incidence)
- Phase C: Hypotheses & interventions (prompt structure, batching, memory handoff rules)
- Phase D: A/B tests and policy rollouts
