
# scripts/normalize_sessions.py
import csv, json, pathlib
from datetime import datetime

ROOT = pathlib.Path(__file__).resolve().parents[1]
infile = ROOT / "data" / "sessions.csv"
outfile = ROOT / "data" / "sessions_normalized.csv"

def parse_row(row):
    # timestamp,device_id,device_type,os_version,app_version,latency_ms,token_rate,errors,context_switch,task_type,outcome
    ts, device_id, device_type, os_ver, app_ver, lat_ms, tok_rate, errors, ctx, task, outcome = row
    return {
        "timestamp": ts,
        "device_id": device_id,
        "device_type": device_type,
        "os_version": os_ver,
        "app_version": app_ver,
        "latency_ms": float(lat_ms),
        "token_rate": float(tok_rate),
        "errors": (errors.split("|") if errors else []),
        "context_switch": (ctx.lower()=="true"),
        "task_type": task,
        "outcome": outcome
    }

if __name__ == "__main__":
    infile.parent.mkdir(parents=True, exist_ok=True)
    if not infile.exists():
        infile.write_text("timestamp,device_id,device_type,os_version,app_version,latency_ms,token_rate,errors,context_switch,task_type,outcome\n", encoding="utf-8")
    rows = []
    with open(infile, newline="", encoding="utf-8") as f:
        reader = csv.reader(f)
        header = next(reader, None)  # skip header if present
        for row in reader:
            if len(row) < 11:
                continue
            rows.append(parse_row(row))
    # write normalized with same header
    with open(outfile, "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=["timestamp","device_id","device_type","os_version","app_version","latency_ms","token_rate","errors","context_switch","task_type","outcome"])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"Wrote {outfile} with {len(rows)} rows")
